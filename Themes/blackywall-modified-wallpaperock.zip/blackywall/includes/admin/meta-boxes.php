<?php
/**
 * Initialize the meta boxes. 
 */
add_action( 'admin_init', '_custom_meta_boxes' );

/**
 * Meta Boxes kentooz code.
 *
 * @return    void
 *
 * @access    private
 * @since     2.0
 */
function _custom_meta_boxes() {
  
  /**
   * Create a custom meta boxes array that we pass to 
   * the OptionTree Meta Box API Class.
   */
   $sidebars_new = ot_get_option( 'ktz_sidebars', array() );
   
  $sidebars= array(
  	array(
  		'label' => 'Default',
  		'value' => 'default'
  	)
  );
  
  foreach ($sidebars_new as $sidebar_new) {
  	$array=array(
  		'label' => $sidebar_new['title'],
  		'value' => $sidebar_new['slug']
  	);
  	array_push($sidebars, $array);
  }
  
  $general_page = array(
    'id'          => 'general_page',
    'title'       => 'Page options',
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => 'General',
        'id'          => 'general_option',
        'type'        => 'tab'
      ),
      array(
        'label'       => __( 'Sidebar Layout', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_layout',
        'type'        => 'radio-image',
        'desc'        => __( 'Select default sidebar for your this post / page.', 'ktz_theme_textdomain' ),
		'choices'     => sidebar_select(),
        'std'         => 'right',
      ), 
      array(
        'label'       => 'Sidebar',
        'id'          => 'ktz_meta_sidebar',
        'type'        => 'select',
        'desc'        => 'Select the exclusive sidebar for this post / page.',
        'choices'     => $sidebars,
        'std'         => 'default',
      ),
      array(
        'label'       => 'Background',
        'id'          => 'ktz_dynamicbg',
        'type'        => 'background',
        'desc'        => 'This setting background for exclusive pages. Please select your background for your background pages.',
        'std'         => '',
      ),
      array(
        'label'       => 'SEO option',
        'id'          => 'seo_option',
        'type'        => 'tab'
      ),
      array(
        'label'       => 'Information',
        'id'          => 'ktz_textblock',
        'type'        => 'textblock',
        'desc'        => __( 'For more information, if you use SEO plugin like yoast or AIO, please disable kentooz SEO, you can disable it via theme option -> SEO and leave blank this options.', 'ktz_theme_textdomain' ),
      ),
      array(
        'label'       => 'Meta Description',
        'id'          => 'ktz_meta_description',
        'type'        => 'textarea-simple',
        'desc'        => 'This Meta Description will be used in facebook share and google search results. If you leave blank this options, so we system will detect your first content. If you use plugin SEO please disable SEO featured via themes options.',
        'std'         => '',
        'rows'        => '5',
      ),
      array(
        'label'       => 'Meta keyword',
        'id'          => 'ktz_meta_keywords',
        'type'        => 'textarea-simple',
        'desc'        => 'This Meta keywords will be used in google search results. If you leave blank this options, so we system will detect automatic keywords for your meta. If you use plugin SEO please disable SEO featured via themes options.',
        'std'         => '',
        'rows'        => '5',
      ),
      array(
        'label'       => __( 'Enable noindex in meta robot?', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_noindex',
        'type'        => 'radio',
        'desc'        => __( 'Please check yes for to ask search engines not to index this page.', 'ktz_theme_textdomain' ),
        'choices'     => array(
          array (
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array (
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'no',
      ),
      array(
        'label'       => __( 'Enable nofollow in meta robot?', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_nofollow',
        'type'        => 'radio',
        'desc'        => __( 'Please check yes for to ask search engines not to follow links from this page.', 'ktz_theme_textdomain' ),
        'choices'     => array(
          array (
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array (
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'no',
      ),
      array(
        'label'       => __( 'Enable noodp in meta robot?', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_noodp',
        'type'        => 'radio',
        'desc'        => __( 'Please check yes for to ask search engines not to use descriptions from the Open Directory Project for this page.', 'ktz_theme_textdomain' ),
        'choices'     => array(
          array (
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array (
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'no',
      ),
      array(
        'label'       => __( 'Enable noydir in meta robot?', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_noydir',
        'type'        => 'radio',
        'desc'        => __( 'Check this box to ask Yahoo! not to use descriptions from the Yahoo! directory for this page.', 'ktz_theme_textdomain' ),
        'choices'     => array(
          array (
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array (
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'no',
      ),
  	)
  );  
  
  $general_post = array(
    'id'          => 'post_option',
    'title'       => 'Post options',
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'label'       => 'General',
        'id'          => 'general_option',
        'type'        => 'tab'
      ),
      array(
        'label'       => __( 'Sidebar Layout', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_layout',
        'type'        => 'radio-image',
        'desc'        => __( 'Select default sidebar for your this post / page.', 'ktz_theme_textdomain' ),
		'choices'     => sidebar_select(),
        'std'         => 'right',
      ), 
      array(
        'label'       => 'Sidebar',
        'id'          => 'ktz_meta_sidebar',
        'type'        => 'select',
        'desc'        => 'Select the exclusive sidebar for this post / page.',
        'choices'     => $sidebars,
        'std'         => 'default',
      ),
      array(
        'label'       => 'Background',
        'id'          => 'ktz_dynamicbg',
        'type'        => 'background',
        'desc'        => 'This setting background for exclusive pages. Please select your background for your background pages.',
        'std'         => '',
      ),
      array(
        'label'       => 'SEO option',
        'id'          => 'seo_option',
        'type'        => 'tab'
      ),
      array(
        'label'       => 'Information',
        'id'          => 'ktz_textblock',
        'type'        => 'textblock',
        'desc'        => __( 'For more information, if you use SEO plugin like yoast or AIO, please disable kentooz SEO, you can disable it via theme option -> SEO and leave blank this options.','ktz_theme_textdomain' ),
      ),
      array(
        'label'       => 'Meta Description',
        'id'          => 'ktz_meta_description',
        'type'        => 'textarea-simple',
        'desc'        => 'This Meta Description will be used in facebook share and google search results. If you leave blank this options, so we system will detect your first content. If you use plugin SEO please disable SEO featured via themes options.',
        'std'         => '',
        'rows'        => '5',
      ),
      array(
        'label'       => 'Meta keyword',
        'id'          => 'ktz_meta_keywords',
        'type'        => 'textarea-simple',
        'desc'        => 'This Meta keywords will be used in google search results. If you leave blank this options, so we system will detect automatic keywords for your meta. If you use plugin SEO please disable SEO featured via themes options.',
        'std'         => '',
        'rows'        => '5',
      ),
      array(
        'label'       => __( 'Enable noindex in meta robot?', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_noindex',
        'type'        => 'radio',
        'desc'        => __( 'Please check yes for to ask search engines not to index this page.', 'ktz_theme_textdomain' ),
        'choices'     => array(
          array (
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array (
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'no',
      ),
      array(
        'label'       => __( 'Enable nofollow in meta robot?', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_nofollow',
        'type'        => 'radio',
        'desc'        => __( 'Please check yes for to ask search engines not to follow links from this page.', 'ktz_theme_textdomain' ),
        'choices'     => array(
          array (
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array (
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'no',
      ),
      array(
        'label'       => __( 'Enable noodp in meta robot?', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_noodp',
        'type'        => 'radio',
        'desc'        => __( 'Please check yes for to ask search engines not to use descriptions from the Open Directory Project for this page.', 'ktz_theme_textdomain' ),
        'choices'     => array(
          array (
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array (
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'no',
      ),
      array(
        'label'       => __( 'Enable noydir in meta robot?', 'ktz_theme_textdomain' ),
        'id'          => 'ktz_meta_noydir',
        'type'        => 'radio',
        'desc'        => __( 'Check this box to ask Yahoo! not to use descriptions from the Yahoo! directory for this page.', 'ktz_theme_textdomain' ),
        'choices'     => array(
          array (
            'label'       => 'Yes',
            'value'       => 'yes'
          ),
          array (
            'label'       => 'No',
            'value'       => 'no'
          )
        ),
        'std'         => 'no',
      ),
    )
  );
 
  
  /**
   * Register our meta boxes using the 
   * ot_register_meta_box() function.
   */
  ot_register_meta_box( $general_post );
  ot_register_meta_box( $general_page );

}