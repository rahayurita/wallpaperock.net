/*
 * Copyright (c) kentooz
 * Kentooz Theme Custom Javascript
 */
 
var $ = jQuery.noConflict();

(function( $ ) {
	/* http://www.w3schools.com/js/js_strict.asp */
	"use strict";
	
$( document ).ready( function () {
// JS TOOLTIPS
	$('ul.ktz-socialicon a, ul.sharethis a').tooltip({placement: 'top'});

// JS TABS - Select first tab in shortcode
	$('#ktztab a:first, #kentooz-comment a:first').tab('show'); 
	
// JS Dropdown
	$('.js-activated').dropdownHover().dropdown();

// Back to top	
	var $scrolltotop = $("#ktz-backtotop");
	$scrolltotop.css('display', 'none');
	$(function () {
		$(window).scroll(function () {
			if ($(this).scrollTop() > 100) {
				$scrolltotop.slideDown('fast');
			} else {
				$scrolltotop.slideUp('fast');
			}
		});
		$scrolltotop.click(function () {
			$('body,html').animate({
				scrollTop: 0
			}, 'fast');
			return false;
		});
	});
	
// FB Script
	(function(w, d, s) {
	function go(){
		var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
			if (d.getElementById(id)) {return;}
			js = d.createElement(s); js.src = url; js.id = id;
			fjs.parentNode.insertBefore(js, fjs);
		};
		load('//connect.facebook.net/en_US/all.js#xfbml=1', 'fbjssdk');
	}
	if (w.addEventListener) { w.addEventListener("load", go, false); }
	else if (w.attachEvent) { w.attachEvent("onload",go); }
	}(window, document, 'script'));
// Pin it
	(function(d){
		var f = d.getElementsByTagName('SCRIPT')[0], p = d.createElement('SCRIPT');
		p.type = 'text/javascript';
		p.async = true;
		p.setAttribute('data-pin-hover', true);
		p.setAttribute('data-pin-color', 'red');
		p.setAttribute('data-pin-height', '28' );
		p.src = '//assets.pinterest.com/js/pinit.js';
		f.parentNode.insertBefore(p, f);
	}(document));
	
}); // End document Ready
})(jQuery);