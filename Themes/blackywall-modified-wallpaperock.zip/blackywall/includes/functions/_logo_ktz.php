<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ THEMES FUNCTION
/* Website    : http://www.kentooz.com
/* The Author : Gian Mokhammad Ramadhan (http://www.gianmr.com)
/* Twitter    : http://www.twitter.com/g14nnakal 
/* Facebook   : http://www.facebook.com/gianmr
/*-----------------------------------------------*/

// Do not load directly...
if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/*
* Add logo with dynamic metatag - main page
* add_action( 'do_ktz_logo', 'ktz_headlogo' ); in init.php
*/
if ( !function_exists('ktz_headlogo') ) :
function ktz_headlogo() { 
	$get_logo_image = ot_get_option('ktz_logo');
	if (ot_get_option('ktz_logo_actived') == 'yes') { 
		echo '<a href="' . home_url() . '" class="navbar-brand"><img src="' . $get_logo_image . '" class="img-responsive" alt="' . get_bloginfo('name') . '" title="' . get_bloginfo('name') . '" /></a>';
		if( (is_single() || is_page() || is_archive() || is_search()) and !(is_front_page()) ) :
			echo '<a class="hidden" href="'. home_url() . '" class="navbar-brand" title="' . get_bloginfo('name') . '">' . get_bloginfo('name') . '</a>';
		else : 
			echo '<h1 class="hidden"><a href="'. home_url() . '" title="' . get_bloginfo('name') . '">' . get_bloginfo('name') . '</a></h1>';
		endif;
		} else { 
		if( (is_single() || is_page() || is_archive()) and !(is_front_page()) ) :
		echo '<a href="'. home_url() . '" class="navbar-brand" title="' . get_bloginfo('name') . '">';
		if ( ot_get_option('ktz_icon_name') != '' )  { echo '<span class="' . ot_get_option('ktz_icon_name') . '"></span> '; }
		echo get_bloginfo('name') . '</a>';
		else : 
		echo '<h1><a href="'. home_url() . '" class="navbar-brand" title="' . get_bloginfo('name') . '">';
		if ( ot_get_option('ktz_icon_name') != '' ) { echo '<span class="' . ot_get_option('ktz_icon_name') . '"></span> '; }
		echo get_bloginfo('name') . '</a></h1>';
		endif;
		}	
	} 
endif;

/*
# Add logo squeeze page
*/
if ( !function_exists('ktz_headlogo_squeeze') ) :
function ktz_headlogo_squeeze() { 
	if (ot_get_option('ktz_logo_squeeze_activated') == 'yes') { 
	$get_logo_image = ot_get_option('ktz_logo_squeeze');
		echo '<div id="logo-squeeze-img"><div id="logo-squeeze">';
		echo '<a href="' . home_url() . '" id="logo-squeeze" title="' . get_bloginfo('name') . '"><img src="' . $get_logo_image . '" alt="' . get_bloginfo('name') . '" title="' . get_bloginfo('name') . '" /></a>';
		echo '<h1 class="homeblogtit-hide" style="display:none"><a href="'. home_url() . '" title="' . ot_get_option('ktz_logo_squeeze_name') . '">' . ot_get_option('ktz_logo_squeeze_name') . '</a></h1>';
		echo '<h2 class="desc-hide" style="display:none">' . ot_get_option('ktz_logo_squeeze_desc') . '</h2>';
		echo '</div></div>';
		} else { 		
		echo '<div class="logo-squeeze-text clearfix"><div id="logo">';
		echo '<h1 class="homeblogtit"><a href="'. home_url() . '" title="' . ot_get_option('ktz_logo_squeeze_name') . '">';
		if ( ot_get_option('ktz_icon_squeeze_name') != ''  ) { echo '<span class="' . ot_get_option('ktz_icon_squeeze_name') . '"></span> '; }
		echo ot_get_option('ktz_logo_squeeze_name') . '</a></h1>';
		echo '<h2 class="desc">' . ot_get_option('ktz_logo_squeeze_desc') . '</h2>';
		echo '</div></div>';
		}	
	} 
endif;