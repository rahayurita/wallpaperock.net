<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ THEMES FUNCTION
/* Website    : http://www.kentooz.com
/* The Author : Gian Mokhammad Ramadhan (http://www.gianmr.com)
/* Twitter    : http://www.twitter.com/g14nnakal 
/* Facebook   : http://www.facebook.com/gianmr
/*-----------------------------------------------*/

// Do not load directly...
if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/*
* Add featured images * first in kabar themes
* If has_thumb elseif firstimage else no image
* BFI_thumbs https://github.com/bfintal/bfi_thumb
*/
function get_first_image_src() {
    $content = get_the_content();
    $image_regex = "/<img [^>]*src=[\"']([^\"^']*)[\"']/";
    preg_match($image_regex, $content, $match);

    if (empty($match))
        return "";
    return $match[1];
}
function get_first_image_src_forhead() {
	global $post;
	if (!is_page()) {
		$content = apply_filters('the_content', $post->post_content);
	} else {
		$content = get_the_content();
	}
    $image_regex = "/<img [^>]*src=[\"']([^\"^']*)[\"']/";
    preg_match($image_regex, $content, $match);

    if (empty($match))
        return "";
    return $match[1];
}
function ktz_getpost_images_upload() {
    global $post,$wpdb;
    $postid = $post->ID;
    $results = '';
	$attachment_id = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_parent = $postid AND post_type = 'attachment' AND post_mime_type LIKE 'image/%%' LIMIT 1 ;" );
    // get the correct image html for the selected size
	$image = wp_get_attachment_image_src($attachment_id, 'full');
	$results = $image[0];
    return $results;
}

if ( !function_exists('ktz_featured_original') ) :
function ktz_featured_original() {
	global $post;
	$permalink = get_permalink();
	$title = get_the_title();
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$get_imgpost_upload = ktz_getpost_images_upload();
	$fisrtimg_url = get_first_image_src(); 
	if ( $img_url ) { 
		echo $img_url;
	} elseif ( $fisrtimg_url ) {
		echo $fisrtimg_url;
	} elseif ( $get_imgpost_upload ) {
		echo $get_imgpost_upload;
	} else { 
		echo '';
	} 
} 
endif;
if ( !function_exists('ktz_featured_just_img_link') ) :
function ktz_featured_just_img_link( $width, $height ) { 
	global $post;
	$permalink = get_permalink();
	$title = get_the_title();
	$params = array( 'width' => $width, 'height' => $height, 'crop' => true );
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$fisrtimg_url = get_first_image_src(); 
	$image = bfi_thumb( $img_url, $params ); //resize & crop featured image
	$first_image = bfi_thumb( $fisrtimg_url, $params ); 
	$get_imgpost_upload = ktz_getpost_images_upload();
	$image_upload = bfi_thumb( $get_imgpost_upload, $params );
	$img_default = get_template_directory_uri() . '/includes/assets/img/no-image/image-blank.jpg'; 
	$default_image = bfi_thumb( $img_default, $params ); 
	if ( $image ) { 
		echo $image;
	} elseif ( $first_image ) {
		echo $first_image;
	} elseif ( $image_upload ) {
		echo $image_upload;
	} else {
		echo $default_image;
	} 
} 
endif;
if ( !function_exists('ktz_featured_just_img') ) :
function ktz_featured_just_img( $width, $height ) { 
	global $post;
	$permalink = get_permalink();
	$title = get_the_title();
	$params = array( 'width' => $width, 'height' => $height, 'crop' => true );
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$fisrtimg_url = get_first_image_src(); 
	$image = bfi_thumb( $img_url, $params ); //resize & crop featured image
	$first_image = bfi_thumb( $fisrtimg_url, $params ); 	
	$get_imgpost_upload = ktz_getpost_images_upload();
	$image_upload = bfi_thumb( $get_imgpost_upload, $params );
	$img_default = get_template_directory_uri() . '/includes/assets/img/no-image/image-blank.jpg'; 
	$default_image = bfi_thumb( $img_default, $params ); 
	if ( $image ) { 
		echo '<img src="' . $image . '" alt="' . $title . '" width="'.$width.'" height="'.$height.'" title="' . $title . '" />';
	} elseif ( $first_image ) {
		echo '<img src="' . $first_image . '" alt="' . $title . '" width="'.$width.'" height="'.$height.'" title="' . $title . '" />';
	} elseif ( $image_upload ) {
		echo '<img src="' . $image_upload . '" alt="' . $title . '" width="'.$width.'" height="'.$height.'" title="' . $title . '" />';;
	} else { 
		echo '<img src="' . $default_image . '" alt="' . $title . '" width="'.$width.'" height="'.$height.'" title="' . $title . '" />';
	} 
} 
endif;
if ( !function_exists('ktz_featured_just_img_width') ) :
function ktz_featured_just_img_width( $width ) { 
	global $post;
	$permalink = get_permalink();
	$title = get_the_title();
	$params = array( 'width' => $width );
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$fisrtimg_url = get_first_image_src(); 
	$image = bfi_thumb( $img_url, $params ); //resize & crop featured image
	$first_image = bfi_thumb( $fisrtimg_url, $params ); 
	$get_imgpost_upload = ktz_getpost_images_upload();
	$image_upload = bfi_thumb( $get_imgpost_upload, $params );
	$img_default = get_template_directory_uri() . '/includes/assets/img/no-image/image-blank.jpg'; 
	$default_image = bfi_thumb( $img_default, $params ); 
	if ( $image ) { 
		echo '<img src="' . $image . '" alt="' . $title . '" width="'.$width.'" height="auto" title="' . $title . '" />';
	} elseif ( $first_image ) {
		echo '<img src="' . $first_image . '" alt="' . $title . '" width="'.$width.'" height="auto" title="' . $title . '" />';
	} elseif ( $image_upload ) {
		echo '<img src="' . $image_upload . '" alt="' . $title . '" width="'.$width.'" height="auto" title="' . $title . '" />';;
	} else { 
		echo '<img src="' . $default_image . '" alt="' . $title . '" width="'.$width.'" height="auto" title="' . $title . '" />';
	} 
} 
endif;
if ( !function_exists('ktz_featured_img') ) :
function ktz_featured_img( $width, $height ) { 
	global $post;
	$permalink = get_permalink();
	$title = get_the_title();
	$params = array( 'width' => $width, 'height' => $height, 'crop' => true );
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$fisrtimg_url = get_first_image_src(); 
	$image = bfi_thumb( $img_url, $params ); //resize & crop featured image
	$first_image = bfi_thumb( $fisrtimg_url, $params ); 
	$get_imgpost_upload = ktz_getpost_images_upload();
	$image_upload = bfi_thumb( $get_imgpost_upload, $params );
	$img_default = get_template_directory_uri() . '/includes/assets/img/no-image/image-blank.jpg'; 
	$default_image = bfi_thumb( $img_default, $params ); 
	if ( $image ) { 
		echo '<a href="' . $permalink . '" class="ktz_thumbnail pull-left" title="Permalink to ' . $title . '">';
		echo '<img src="' . $image . '" alt="' . $title . '" width="'.$width.'" height="'.$height.'" title="' . $title . '" />';
		echo '</a>';
	} elseif ( $first_image ) {
		echo '<a href="' . $permalink . '" class="ktz_thumbnail pull-left" title="Permalink to ' . $title . '">';
		echo '<img src="' . $first_image . '" alt="' . $title . '" width="'.$width.'" height="'.$height.'" title="' . $title . '" />';
		echo '</a>';
	} elseif ( $image_upload ) {
		echo '<a href="' . $permalink . '" class="ktz_thumbnail pull-left" title="Permalink to ' . $title . '">';
		echo '<img src="' . $image_upload . '" alt="' . $title . '" width="'.$width.'" height="'.$height.'" title="' . $title . '" />';
		echo '</a>';
	} else { 
		echo '<a href="' . $permalink . '" class="ktz_thumbnail pull-left" title="Permalink to ' . $title . '">';
		echo '<img src="' . $default_image . '" alt="' . $title . '" width="'.$width.'" height="'.$height.'" title="' . $title . '" />';
		echo '</a>';
	} 
} 
endif;

if ( !function_exists('ktz_featured_img_width') ) :
function ktz_featured_img_width( $width ) { 
	global $post;
	$permalink = get_permalink();
	$title = get_the_title();
	$params = array( 'width' => $width );
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$fisrtimg_url = get_first_image_src(); 
	$image = bfi_thumb( $img_url, $params ); //resize & crop featured image
	$first_image = bfi_thumb( $fisrtimg_url, $params ); 
	$get_imgpost_upload = ktz_getpost_images_upload();
	$image_upload = bfi_thumb( $get_imgpost_upload, $params );
	$img_default = get_template_directory_uri() . '/includes/assets/img/no-image/image-blank.jpg'; 
	$default_image = bfi_thumb( $img_default, $params ); 
	if ( $image ) { 
		echo '<a href="' . $permalink . '" class="ktz_thumbnail" title="Permalink to ' . $title . '">';
		echo '<img src="' . $image . '" alt="Permalink to ' . $title . '" width="'.$width.'" height="auto" title="Permalink to ' . $title . '" />';
		echo '</a>';
	} elseif ( $first_image ) {
		echo '<a href="' . $permalink . '" class="ktz_thumbnail" title="Permalink to ' . $title . '">';
		echo '<img src="' . $first_image . '" alt="Permalink to ' . $title . '" width="'.$width.'" height="auto" title="Permalink to ' . $title . '" />';
		echo '</a>';
	} elseif ( $image_upload ) {
		echo '<a href="' . $permalink . '" class="ktz_thumbnail" title="Permalink to ' . $title . '">';
		echo '<img src="' . $image_upload . '" alt="Permalink to ' . $title . '" width="'.$width.'" height="auto" title="Permalink to ' . $title . '" />';
		echo '</a>';
	} else { 
		echo '<a href="' . $permalink . '" class="ktz_thumbnail" title="Permalink to ' . $title . '">';
		echo '<img src="' . $default_image . '" alt="Permalink to ' . $title . '" width="'.$width.'" height="auto" title="Permalink to ' . $title . '" />';
		echo '</a>';
	} 
} 
endif;

/*******************************************
# Add Images Download For Wallpaper Themes
# Available only in kentooz wallpaper themes
*******************************************/

if ( !function_exists('ktz_get_dl_image_single') ) :
function ktz_get_dl_image_single() { 
	global $post;
	$params_handphone = array( 'width' => 640, 'height' => 480, 'crop' => true );
	$params_tablet = array( 'width' => 1024, 'height' => 600, 'crop' => true );
	$thumb = get_post_thumbnail_id();
	$img_url = wp_get_attachment_url( $thumb,'full' ); 
	$get_imgpost_upload = ktz_getpost_images_upload();
	$fisrtimg_url = get_first_image_src(); 
	echo '<div class="button-dl-wrap ktz-single">';
	echo '<span class="button-dl-text"><b>Download by size:</b></span>';
	if ( $img_url ) { 
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . bfi_thumb( $img_url, $params_handphone ) . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Handphone';
		echo '</a>/';
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . bfi_thumb( $img_url, $params_tablet ) . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Tablet';
		echo '</a>/';
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . $img_url . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Desktop (Original size)';
		echo '</a>';
	} elseif ( $fisrtimg_url ) {
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . bfi_thumb( $fisrtimg_url, $params_handphone ) . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Handphone';
		echo '</a>/';
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . bfi_thumb( $fisrtimg_url, $params_tablet ) . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Tablet';
		echo '</a>/';
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . $fisrtimg_url . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Desktop (Original size)';
		echo '</a>';
	} elseif ( $get_imgpost_upload ) {
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . bfi_thumb( $get_imgpost_upload, $params_handphone ) . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Handphone';
		echo '</a>/';
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . bfi_thumb( $get_imgpost_upload, $params_tablet ) . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Tablet';
		echo '</a>/';
		echo '<a class="button-dl" target="_blank" tabindex="-1" href="' . $get_imgpost_upload . '" title="' . the_title_attribute('echo=0') . '" >';
		echo 'Desktop (Original size)';
		echo '</a>';
	} else {
		echo 'No Image available';
	}
	echo '</div>';
}
endif;