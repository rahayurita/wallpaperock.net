<?php
/*
/*-----------------------------------------------*/
/* KENTOOZ THEMES FUNCTION
/* Website    : http://www.kentooz.com
/* The Author : Gian Mokhammad Ramadhan (http://www.gianmr.com)
/* Twitter    : http://www.twitter.com/g14nnakal 
/* Facebook   : http://www.facebook.com/gianmr
/*-----------------------------------------------*/

// Do not load directly...
if ( ! defined( 'ABSPATH' ) ) { die( 'Direct access forbidden.' ); }

/*******************************************
# Register javascript on hook system ~ header
*******************************************/
function ktz_register_jascripts() {
	if( !is_admin() ) {
		wp_register_script( 'modernizr-respon',ktz_url . 'includes/assets/js/modernizr-2.6.2-respond-1.3.0.min.js', array(), false, false );
		wp_register_script( 'ktz-jsscript-js',ktz_url . 'includes/assets/js/jsscript.min.js',array('jquery'), false, true );
		wp_register_script( 'ktz-rating-js',ktz_url . 'includes/assets/js/rating.js',array('jquery'), false, true );
		wp_register_script( 'ktz-main-js',ktz_url . 'includes/assets/js/custom.main.js',array('jquery'), false, true );
	}
}

/*******************************************
# Enqueue javascript on hook system ~ header
*******************************************/
function ktz_jsscripts() {
	global $is_IE, $post;
	if( !is_admin() ) {
		if ( is_singular() ) { wp_enqueue_script( 'comment-reply' ); }
		wp_enqueue_script('modernizr-respon');
		wp_enqueue_script('ktz-jsscript-js');
		wp_enqueue_script('ktz-rating-js');
		wp_enqueue_script('ktz-main-js');
		wp_localize_script('ktz-rating-js', 'ktz_ajax_data', array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'codes' => array(
				'SUCCESS' => 1,
				'PREVIOUSLY_VOTED' => 0,
				'REQUEST_ERROR' => 2,
				'UNKNOWN' => -1
			),
			'messages' => array(
				'success' => __('You\'ve voted correctly', 'ktz_theme_textdomain'),
				'previously_voted' => __('You had previously voted', 'ktz_theme_textdomain'),
				'request_error' => __('The request was malformed, try again', 'ktz_theme_textdomain'),
				'unknown' => __('An unknown error has occurred, try to vote again', 'ktz_theme_textdomain')
			)
		));
	}
}