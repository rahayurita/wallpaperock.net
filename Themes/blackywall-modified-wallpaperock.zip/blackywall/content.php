<?php
/**
 * KENTOOZ DEFAULD POST TEMPLATE
**/
?>
<article id="post-<?php the_ID(); ?>" <?php if (is_404()): post_class('col-md-3 ktz-resp-box'); else: post_class('col-md-4 ktz-resp-box'); endif; ?>>
	<div class="box-post ktz-archive">
	<div class="ktz-headbox">
	<?php ktz_posted_title_h('h2','entry-title ktz-titlemini'); ?>
	<div class="meta-post" style="display:none;">
		<?php hook_ktz_content_meta(); ?>
	</div>
	</div>
	<div class="clearfix ktz-featuredimage">
		<?php 	
		if (has_post_format('gallery')) {
			echo ktz_gallery_slide();
		} else {
			echo '<div class="ktz-featuredimg">';
			echo ktz_featured_img( 240, 150 ); // New kentooz image croping just call ktz_featured_img( width, height )
			echo '</div>';
		}
		?>
	</div>

	</div>
</article><!-- #post-<?php the_ID(); ?> -->