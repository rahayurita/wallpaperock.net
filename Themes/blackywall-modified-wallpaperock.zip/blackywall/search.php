<?php 
/**
 * KENTOOZ SEARCH PAGE TEMPLATE
**/
if (isset($_REQUEST['s'])) {
$termstring = urldecode($_REQUEST['s']);
} else {
$termstring = '';}
get_header(); ?>
	<section class="col-md-12">
	<div class="row">
	<?php if ( ot_get_option('ktz_sb_layout') == 'left' ) : get_sidebar(); endif; ?>
		<div role="main" class="main col-md-9">
		<section class="new-content">
		<div class="ktz-titlepage"><h1><?php printf( '<span class="ktz-blocktitle">' . __( 'Search Results for: %s', 'ktz_theme_textdomain' ), '' . get_search_query() . '</span>' ); ?></h1>		</div>
		<?php if ( have_posts() ) : 
		echo '<div class="row">';
		while ( have_posts() ) : the_post();
				get_template_part( 'content', get_post_format() );
		endwhile; ?>
		</div>
		<div class="clearfix"></div>
		<nav id="nav-index">
			<?php ktz_navigation(); ?>
		</nav>
		<?php else : $termstring = $s;
		ktz_get_AGC( $termstring ); 
		endif;
		?>
		</section>
		</div>
	<?php get_sidebar(); ?>
	</div>
	</section>
<?php get_footer(); ?>
