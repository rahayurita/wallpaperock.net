<?php
/**
 * KENTOOZ SINGLE POST TEMPLATE
**/
global $post;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('ktz-single'); ?>>
	<?php ktz_setPostViews(get_the_ID()); //get view for single post ?>
	<div class="ktz-single-box">
	<div class="entry-body">
		<?php hook_ktz_singleheadban(); ?>
		<h1 class="entry-title clearfix"><?php the_title(); ?></h1>
		<div class="metasingle-aftertitle">
			<div class="ktz-inner-metasingle">
				<?php hook_ktz_content_single_meta(); ?>
				<?php echo ktz_getPostViews($post->ID); ?>
				<?php echo ktz_ajaxstar_SEO_single(); ?>
				<?php edit_post_link( __( 'Edit', 'ktz_theme_textdomain' ), '<span class="entry-edit">', '</span>' ); ?>
			</div>
		</div>
		<div class="entry-content ktz-wrap-content-single clearfix ktz-post">
		<?php echo ktz_content_single_firstp(); ?>
		<?php echo ktz_ban46860_singletit(); ?>
		<?php 
			if ( ot_get_option('ktz_active_autocontent') == 'yes' ) {
				echo '<div class="ktz-featuredimg clearfix">';
				echo '<img src="';
					ktz_featured_original(); 
				echo '" title="Image for ' . get_the_title() . '" alt="Image for ' . get_the_title() . '" />';	
				echo '</div>';
				} 
		?>
		<?php echo ktz_content_single(); ?>
		<?php echo ktz_link_pages(); ?>
		<?php do_action( 'ktz_ban46860_singlefoot' );?>
		<?php 
		if ( ot_get_option('ktz_active_download') == 'yes' ) {
			ktz_get_dl_image_single();
		}
		?>
		<?php $posttags = get_the_tags();  
		if ($posttags) {  
		echo '<p class="ktz-tagcontent">Tags: ';
		foreach($posttags as $tag) {  
			echo '<a href=" ' . get_tag_link($tag->term_id) . '" title="Tag '. $tag->name .'">#';
			echo $tag->name;   
			echo '</a> ';
			}  
		echo '</p>';
		} ?>
		<?php hook_ktz_single_agc(); ?>
		<?php hook_ktz_singleshare(); ?>
		</div>
	</div>
	</div>
	
</article><!-- #post-<?php the_ID(); ?> -->
