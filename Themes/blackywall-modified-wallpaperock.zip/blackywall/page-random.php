<?php 
/**
 * Template Name: Random post
*/ 
get_header(); ?>
	<section class="col-md-12">
	<div class="row">
	<?php if ( ot_get_option('ktz_sb_layout') == 'left' ) : get_sidebar(); endif; ?>
		<div role="main" class="main col-md-9">
		<section class="new-content">
		<?php hook_ktz_aftermenubanner(); ?>
		<div class="ktz-titlepage"><h1><span class="ktz-blocktitle"><?php echo get_the_title();	?></span></h1></div>
		<?php 
		$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
		global $paged;		
		query_posts(array(
			'post_type' => 'post',
			'post_status' => 'publish', 
			'ignore_sticky_posts' => 1, 
			'orderby' => 'rand', 
			'order' => 'DESC',
			'paged' => $paged)); ?>
		<?php $i = 1; if ( have_posts() ) : 
		echo '<div class="row">';
		while ( have_posts() ) : the_post();
			if($i%3 == 0) :
				get_template_part( 'content', get_post_format() );
				echo '<div class="clearfix"></div>';
			else :
				get_template_part( 'content', get_post_format() );
			endif;
			$i++;
		endwhile; ?>
		</div>
		<div class="clearfix"></div>
		<nav id="nav-index">
			<?php ktz_navigation(); ?>
		</nav>
		<?php else : ktz_post_notfound(); endif; ?>
		</section>
		</div>
	<?php get_sidebar(); ?>
	</div>
	</section>
<?php get_footer(); ?>
